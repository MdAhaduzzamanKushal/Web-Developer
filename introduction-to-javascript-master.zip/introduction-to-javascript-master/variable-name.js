// good variable
var price = 29;

vaR price = 29;
Var price = 29;
VAR price = 29;

// 1. variable name can not be any keywords
var false = 96;
var return = true;

// 2. variable name has to be in one work. No space
var my home address = "New California";

// 3. variable name can not have quotation
var "name" = "Tom Hanks";

// 4. variable name can not starts with a number but can ends with a number
var 99Club = 1964;
var club25 = 2025;

// 5. How to use long names
// can not use dash
var user-name = "raj bappa"; 

var user_name = "bappa raj";
var usercurrenthomeaddress = "andor killa bandor ban";
var user_home_address = "andor killa bandor ban"; // snake case
var userHomeAddress = "andor killa bandor ban"; // camel case: we will use this one
var UserHomeAddress = "andor killa bandor ban"; // pascal case

// variable name is case senstive
var person = 25;
var Person = 35;
