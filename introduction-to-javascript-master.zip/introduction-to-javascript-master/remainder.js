var mangoes = 19;
var person = 7;
var remainder = mangoes % person;
// / this means vagfol
// % this means vagses
console.log(remainder);