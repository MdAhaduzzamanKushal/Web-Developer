/***
 * MATH Needed to Start Larning a Programming language 
 * 1. number ==> 55. 898, -32
 * 2. integer, odd, even: 2, 5, 
 * 3. float: decimal: 2.5, 13.67, 32.69
 * 4. operation: addition, substraction, multiplication, division, remainder
 * 5. percent, 
 * 6. average
 * 7. comparison: >, <, ==, !=, >=, <=
 * 8. oikik: 2 kilo apple and 5 kilo mango:
 * 9. 45, 25, 68, 68, 129, 2: max, min, average, sum
 * 10. series: 
 * :::EXTRA::::
 * 1. Prime
 * 2. permutation
 * 3. Area:
 *  ::::ALWAYS::::
 * Jodi lage....
 * */ 