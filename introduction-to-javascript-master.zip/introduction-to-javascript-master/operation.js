var onionPrice = 20;
var eggPrice = 10;

// addition, subtraction
var totalPrice = onionPrice + eggPrice;
var priceDifference = onionPrice - eggPrice;

// console.log(priceDifference);

// console.log(totalPrice);
// console.log(onionPrice);
// console.log(eggPrice);
// console.log(onionPrice + eggPrice);


// multplication
var orangePrice = 20;
var quantiy = 7;
var totalCost = orangePrice * quantiy;
// console.log(totalCost);


// division
var money = 500;
var player = 10;
var eachPlayer = money / player;
console.log(eachPlayer);