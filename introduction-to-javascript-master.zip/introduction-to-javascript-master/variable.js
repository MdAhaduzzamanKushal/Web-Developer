// vary + able = variable

// numeric
var price = 11;
var age = 17;
var temperature = 38;

// string
var person = "sodor uddin" ;
var location = "andork killa bandorbon" ;
var special = 'alia bhatt' ;

// Boolean
var serious = true;
var isFullMarks = true;
var isSingle = false;