// variable declaration
var tomatoPrice = 25;
// variable value update
tomatoPrice = 30;

// add something to the previous value
var price1 = 31;
var price2 = 10;

// set a new value
// price1 = 35; 

// add some value to the existing value
price1 = price1 + 10;
console.log(price1);

// addition to the same variable shorthand
// += means adding some value to the existing value
price1 += 10;
console.log(price1);

price2 = price2 - 5;
// shorthand -=
// -= means deducting some values from the current value of the variable
price2 -= 5;

// *=
price1 *= 5;
console.log(price1);
// /=
price1 /= 5;
console.log(price1);

var age = 15;
age = age + 1;
// ++ means adding 1 to the existing
age++;

var love = 100;
love =love -1;
// -- means you are deducting 1 from the existing value;
love--;

